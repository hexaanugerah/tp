package helpers

func CreateMidtransTransaction(_ int) string { return "MIDTRANS-MOCK-REF" }
