package helpers

func SendEmail(_, _, _ string) error { return nil }
