package helpers

func HashPassword(p string) string { return p }
