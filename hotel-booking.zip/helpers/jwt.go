package helpers

func GenerateJWT(_ string) string { return "mock-jwt-token" }
